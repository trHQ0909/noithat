from django.urls import path
from .views import category_list_view, product_list_view, products_by_category_view,main_view

urlpatterns = [
    path("categories/", category_list_view, name="category-list"),
    path("category/<int:category_id>/", main_view, name="products_by_category"),  # Lọc sản phẩm theo danh mục
]
